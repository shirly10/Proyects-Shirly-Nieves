function Carreras(evento) {
    evento.preventDefault();
    
    let Nombre = document.getElementById("name").value;
    let Edad = parseInt(document.getElementById("age").value);
    let Telefono = document.getElementById("telephone").value;
    let Email = document.getElementById("email").value;
    let Curso = document.getElementById("curso").value;
    let Carrera = document.getElementById("carrera").value;
    let Ciudad = document.getElementById("city").value;

    if (Edad < 18){
        alert(`La edad minima para ingresar a STEAM ACADEMY es de 7 años y además debes ser mayor de edad o estar respaldado por un mayor de edad y con mucho gusto te agendamos tu clase GRATIS.`);
    }
    else{
        alert(`Su información ha quedado registrada con los siguientes datos \n
        Nombre: ${Nombre}\n
        Edad: ${Edad} \n
        Telefono: ${Telefono}\n
        Carrera de su interes: ${Carrera}\n
        Email de contacto:\n            ${Email}
        Curso de su interes: ${Curso}\n
        y ciudad de residencia: ${Ciudad}\n
        Es un placer para nosotros poder servirle,\n 
        pronto nos estaremos comunicando con usted.`);
    }
}